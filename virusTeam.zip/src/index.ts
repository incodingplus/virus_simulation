import './index.css'
import { People } from './types' 

const resultDiv = document.querySelector('#resultDiv');

let peopleX = 37.32191655510652;
let peopleY = 126.83084311183287;

var container = document.getElementById('map')

var options = { // 지도 기본 설정
    center: new kakao.maps.LatLng(37.32191655510652, 126.83084311183287), //지도의 중심좌표
    minLevel: 2,
    maxLevel: 6,  
    level: 3 //지도의 레벨(확대, 축소 정도)
};

var map = new kakao.maps.Map(container, options); //지도 생성 및 객체 리턴

const NumOfPeople = 500; //사람 수
let peoples: People[] = [];
let people_click:boolean = false;
let currentPeople: kakao.maps.Circle = null;
let currentPosition = null;

kakao.maps.event.addListener(map, 'click', function(mouseEvent) {
    // 클릭한 위도, 경도 정보 가져오기
    var latlng = mouseEvent.latLng;
    console.log(`클릭 좌표: ${latlng}`)
    
    var message = '클릭한 위치의 좌표 (위도,경도) : ' + latlng.getLat() + ', ' + latlng.getLng();

    resultDiv.innerHTML = message;
});

for(let i = 0; i < NumOfPeople; i++){
    displayPeo(peoples[i], i);
}

function displayPeo(people, i){ //Peoples 배열 정보

    let randY = 37.33779306610436 - (Math.random() * 0.04);
    let randX:number = 126.76704681759245 + (Math.random() * 0.1);

    people = new kakao.maps.Circle({
        center : new kakao.maps.LatLng(randY, randX), // 원의 중심좌표
        radius: 5, // 미터 단위의 원의 반지름
        strokeOpacity: 0, // 선의 불투명도 1에서 0 사이의 값이며 0에 가까울수록 투명
        fillColor: 'green', // 채우기 색깔
        fillOpacity: 1  // 채우기 불투명도
    });

    people.setMap(map);
    peoples.push({
        position: {
            x: randX, y: randY,
        },
        velocity: {
            x: 0, y: 0
        },
        circle: people
    });

    kakao.maps.event.addListener(people, 'click', function(mouseEvent){
        people_click = true;
        console.log(people);
        currentPeople = people;
        currentPosition = currentPeople.getPosition();
    });
}

var ANSANrange = [ // 안산시 범위 다각형
    new kakao.maps.LatLng(37.345366013401176, 126.78333668729309),
    new kakao.maps.LatLng(37.35239803210191, 126.8064317710519),
    new kakao.maps.LatLng(37.349186106146135, 126.82693591397667),
    new kakao.maps.LatLng(37.33741173896692, 126.86289287290087),
    new kakao.maps.LatLng(37.33331815195747, 126.87662155964347),
    new kakao.maps.LatLng(37.29995866705562, 126.89174473030477),
    new kakao.maps.LatLng(37.27520467234179, 126.86323127643033),
    new kakao.maps.LatLng(37.255616498182725, 126.84879303952384),
    new kakao.maps.LatLng(37.28014061840822, 126.80977423926493),
    new kakao.maps.LatLng(37.31525692962604, 126.72430964796537),
    new kakao.maps.LatLng(37.33020884672598, 126.73788540580587),
    new kakao.maps.LatLng(37.324822550305214, 126.74702047813423),
    new kakao.maps.LatLng(37.33362248985068, 126.74978938950672),
    new kakao.maps.LatLng(37.340997433317646, 126.76068885204707),
    new kakao.maps.LatLng(37.34071681402399, 126.78339518403493)
];

// 지도에 표시할 다각형을 생성합니다
var polygon = new kakao.maps.Polygon({
    path:ANSANrange,
    strokeWeight: 3,
    strokeColor: '#000000',
    strokeOpacity: 0.8,
    fillOpacity: 0
});

// 안산 범위 다각형 표시
polygon.setMap(map);

const mylocate = document.querySelector<HTMLDivElement>('.mylocate');
const Capslock_alert = document.querySelector<HTMLButtonElement>('.Capslock_alert');

let moveOpts = {
    key: '',
    d: null
}

let panto = false;
var moveLatLng = new kakao.maps.LatLng(peopleX, peopleY);

window.onkeydown = (evt) =>{
    if(evt.getModifierState("CapsLock") == true){
        Capslock_alert.style.filter = 'opacity(100%)';
    }else{
        Capslock_alert.style.filter = 'opacity(0%)';
        if(['w', 'a', 's', 'd'].includes(evt.key) && people_click == true){
            currentPosition = currentPeople.getPosition();
            if((Math.abs(currentPosition.Ma - map.getCenter().getLat()) > 0.00005 || Math.abs(currentPosition.La - map.getCenter().getLng()) > 0.00005) && panto == false){
                console.log("panto!");
                map.panTo(currentPosition);
                moveOpts.key = evt.key;
                moveOpts.d = new Date();
                panto = true;
            }else{
                moveOpts.key = evt.key;
            }
        }else if(evt.keyCode == 27){
            console.log('ESC');
            people_click = false;
            moveOpts.key = '';
            currentPeople = null;
            currentPosition = null;
        }
    }
}
window.onkeyup = (evt)=>{
    if(evt.key == moveOpts.key){
        moveOpts.key = '';
    }
}

const MOVE_PARAMS = {
    'w': {
        vx: 0.00005,
        vy: 0,
    },
    's': {
        vx: -0.00005,
        vy: 0,
    },
    'a': {
        vx: 0,
        vy: -0.00005,
    },
    'd': {
        vx: 0,
        vy: 0.00005,
    }
}
setInterval(() => { // 플레이 w,a,s,d
    const p = MOVE_PARAMS[moveOpts.key];
    if(p != null && currentPeople != null){
        if(+moveOpts.d + 500 < +new Date()){
            currentPosition.La += p.vy;
            currentPosition.Ma += p.vx;
            currentPeople.setPosition(currentPosition);
            map.setCenter(currentPosition);
        }
    }
}, 50);

setInterval(() => {
    for(let i = 0; i < NumOfPeople; i++){
        if(people_click == false){
            const vel = peoples[i].velocity;
            const rand = Math.random();
            if(rand < 0.25){
                vel.x += 0.000005;
            } else if(rand < 0.5){
                vel.x -= 0.000005;
            } else if(rand < 0.75){
                vel.y += 0.000005;
            } else{
                vel.y -= 0.000005;
            }

            if(vel.x > 0.00001){

            }

            peoples[i].position.x += vel.x;
            peoples[i].position.y += vel.y;

            let setPeople = peoples[i].circle;
            let setPeoplePosition = setPeople.getPosition();
            (setPeoplePosition as any).La = peoples[i].position.x;
            (setPeoplePosition as any).Ma = peoples[i].position.y;
            setPeople.setPosition(setPeoplePosition);
        }
    }
}, 50);

// for(let i = 0; i < NumOfPeople; i++){
//         console.log(peoples[i].circle)
// }

setInterval(() => { // 플레이어 위치 표시
    if(moveOpts.key == ''){
        mylocate.style.filter = 'opacity(0%) drop-shadow(0 0 3px black)';
        panto = false;
    } else {
        mylocate.style.filter = 'opacity(100%) drop-shadow(0 0 3px black)';
    }
}, 50)