export interface People {
    position: {
        x: number,
        y: number
    }
    velocity: {
        x: number,
        y: number
    }
    circle: kakao.maps.Circle
}